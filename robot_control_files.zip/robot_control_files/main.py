import os
os.system("(asebamedulla ser:name=Thymio-II &) && sleep 0.3")
import time
import random
from time import sleep
import dbus
import dbus.mainloop.glib
from leds import change_colour
from color_object_detector import ColorDetector

class Thymio:
    def __init__(self):
        self.aseba = self.setup()
        self.comms_setup()
        self.specs_setup()
        # Line avoidance vars
        self.kick_flag = False
        self.timer = -1
        self.corner_flag = False
        self.corner_timer = 0
        # FSM vars
        self.current_state = "RUN"
        self.tagged = False
        self.safe = False
        self.enemy_present = False
        self.x_coord = 0 

    def stop(self):
        left_wheel = 0
        right_wheel = 0
        self.aseba.SendEventName("motor.target", [left_wheel, right_wheel])

    def assignRole(self, role):
        self.role = role
        self.n_communication = 1 if role == "SEEKER" else 2
        self.camera = ColorDetector(role)
        # self.light_red() if role == "SEEKER" else self.light_blue()
            
    def specs_setup(self):
        self.safe_zone_val_range = (700, 800)
        self.line_val_range = (0,400)
        self.base_velocity = 500


    ############## Bus and aseba setup ######################################

    def setup(self):
        print("Setting up")
        dbus.mainloop.glib.DBusGMainLoop(set_as_default=True)
        bus = dbus.SessionBus()
        asebaNetworkObject = bus.get_object('ch.epfl.mobots.Aseba', '/')

        asebaNetwork = dbus.Interface(
            asebaNetworkObject, dbus_interface='ch.epfl.mobots.AsebaNetwork'
        )
        # load the file which is run on the thymio
        asebaNetwork.LoadScripts(
            'thympi.aesl', reply_handler=self.dbusError, error_handler=self.dbusError
        )

        # scanning_thread = Process(target=robot.drive, args=(200,200,))
        return asebaNetwork

    def stopAsebamedulla(self):
        os.system("pkill -n asebamedulla")

    def dbusReply(self):
        # dbus replys can be handled here.
        # Currently ignoring
        pass

    def dbusError(self, e):
        # dbus errors can be handled here.
        # Currently only the error is logged. Maybe interrupt the mainloop here
        print("dbus error: %s" % str(e))


# ----------- Our Functions
    
    ##### LIGTH CONTROLS #####

    def update_colour(self):
        if self.in_safe_zone():
            change_colour(self, "GREEN")
        elif self.tagged:
            change_colour(self, "PURPLE")
        else:
            change_colour(self, "BLUE")

    ##### COMMUNICATION #####
    
    def comms_setup(self):
        self.aseba.SendEventName( "prox.comm.enable", [1])
    
    def send_information(self):
        self.aseba.SendEventName("prox.comm.tx", [1])

    def receive_information(self):
        return self.aseba.GetVariable("thymio-II", "prox.comm.rx")

    ##### SENSORS CONTROL #####
        
    def sens_front(self):
        prox_horizontal = self.aseba.GetVariable("thymio-II", "prox.horizontal")
        return prox_horizontal[0],prox_horizontal[1], prox_horizontal[2], prox_horizontal[3], prox_horizontal[4]
        #right to left
    
    def sens_ground(self):
        prox_ground = self.aseba.GetVariable("thymio-II", "prox.ground.reflected")
        return prox_ground[0], prox_ground[1]  #left,right
    
    def normalize_motor_speed(self, left_motor_speed, right_motor_speed):
        return left_motor_speed/500, right_motor_speed/500

    def denormalize_motos_speed(self, left_motor_speed, right_motor_speed):
        return left_motor_speed*500, right_motor_speed*500
    
    ##### ENVIRONMENT CONDITIONS #####

    def on_line(self):
        res = [True if (val >= self.line_val_range[0] and val <= self.line_val_range[1]) else False for val in self.sens_ground()]
        return [(res[0] and res[1])] + res  # BOTH, LEFT, RIGHT
    
    def in_safe_zone(self):
        result = False
        for sensor in self.sens_ground():
            if sensor >= self.safe_zone_val_range[0] and sensor <= self.safe_zone_val_range[1]:
                result = True
        return result

    def got_tagged(self):
        return True if 1 in self.receive_information() else False

    def kicked(self):
        return True if 2 in self.receive_information() else False
    
    def leave_safe_zone(self, info):
        """
        SEEKER --> 1 
            if avoider receives it, tagged
        AVOIDER --> 2 
            if avoider receives 2 while in safe zone, gotta leave
        """
        return True if self.in_safe_zone() and 2 in info else False

    def test_on_line(self):
        B, L, R = self.on_line()
        L = 0 if L is True else 1
        R = 0 if R is True else 1
        return L, R

    ##### CONTROL #####
    
    def corner_control_timer(self):
        if self.corner_flag:
            self.corner_timer += 1
            if self.corner_timer >= 2000:
                self.corner_flag = False
                self.corner_timer = 0

    def get_wheel_velocities(self,obstacle_avoidance=False, distances=None):
        """
        Simple obstacle avoiding controller that is biased to steer left.
        """
        if obstacle_avoidance:
            l2, l1, m, r1, r2 = distances
            correction = l2 + 2*l1 + 3.5*m - 2*r1 - r2
            correction = correction * 30
        else:
            correction = 0

        if self.corner_flag:
            return (-500, +500)
        if self.on_line()[0]:
            self.corner_flag = True
            return (-500, +500)
        else:
            left_wheel_velocity = self.base_velocity + correction if self.on_line()[2] is False else -(self.base_velocity + correction)
            right_wheel_velocity = self.base_velocity - correction if self.on_line()[1] is False else -(self.base_velocity + correction)
        return (left_wheel_velocity, right_wheel_velocity)

    def drive(self, left_wheel_speed, right_wheel_speed):
        # print("Left_wheel_speed: " + str(left_wheel_speed))
        # print("Right_wheel_speed: " + str(right_wheel_speed))
        left_wheel = left_wheel_speed
        right_wheel = right_wheel_speed

        self.aseba.SendEventName("motor.target", [left_wheel, right_wheel])

    def test_drive(self, inputL, inputR):
        # 1 line, 0 ground
        wL = 1
        wR = 1

        return self.base_velocity*(wL*inputL), self.base_velocity*(wR*inputR)

    
    ##### FSM STATES CHANGES #####
    ##### AVOIDER #####

    def use_NN(self):
        print("N")
        x = self.enemy_detected_avoider()
        print("AAA", x[0])
        if self.enemy_detected_avoider()[0]:
            self._rotate_avoider()
            pass
        else: 
            self._explore()
            return
        
    def enemy_detected_avoider(self):
        list_of_colors, area, x_coord = self.camera.detect()
        if "RED" in list_of_colors :
            return True, x_coord[list_of_colors.index("RED")]
        elif "ORANGE" in list_of_colors:
            return True, x_coord[list_of_colors.index("ORANGE")]
        else:
            return False, 0

    def _rotate_avoider(self):
        print("ROTATEEE")
        for i in range(200):
            self.drive(500, -500)
        self.current_state = "RUN"
        return

    def _scan(self):
        print("SCAN")
        for i in range(1000):
            if self.enemy_detected_avoider()[0]:
                self._rotate_avoider()
                return
            else:
                self.drive(200,200)
        self.current_state = "RUN"
        return

    def _explore(self):
        detection = self.enemy_detected_avoider()[0]
        while detection is False:
            print(detection)
            self.corner_control_timer()
            l,r = self.get_wheel_velocities()
            self.drive(l, r)
        return

    def _run(self):
        print("RUNNNNNNNN")
        while self.current_state == "RUN":
            # check communications
            comms = self.receive_information()
            # check if tagged 
            if self.got_tagged():
                self.current_state="TAGGED"
                return
            # check if in safe
            elif self.in_safe_zone():
                self.current_state ="SAFE"
                return
            else:
                self.use_NN()
                # return

    def _safe(self):
        print("SAFE")
        while self.current_state == "SAFE":
            # check comms
            comms = self.receive_information()
            if self.kicked():
                self.current_state ="KICKED"
                return
            else:
                #stay in safe
                # simple: just stay still
                # advanced: avoid other avoiders, while staying inside the safe zone 
                return
    
    def _kicked(self):
        while self.current_state == "KICKED":
            # self.update_colour()
            # check comms
            comms = self.receive_information()
            # tagged, safe, kicked = self.receive_information()
            # check if tagged
            if self.got_tagged():
            # if tagged:
                self.current_state="TAGGED"
                return
            # check timer
            elif not self.kick_flag: # if we just got kicked
                self.kick_flag = True
                self.timer = int(time.time() + 5)
                continue
            elif self.kick_flag:
                if int(time.time()) <= self.timer:
                    self.use_NN()
                    continue
                else:
                    self.kick_flag = False
                    self.timer = 0
                    self.current_state ="RUN"
                    return

    def _tagged(self):
        print("TAGGEDDDDDD")
        while self.current_state == "TAGGED":
            # game over. change colour and stay still
            self.tagged = True
            self.drive(0,0)

    def state_switch_AVOIDER(self, state):
        if state == "RUN":      return self._run
        if state == "SAFE":     return self._safe
        if state == "SAFE":     return self._run
        if state == "KICKED":   return self._kicked
        if state == "TAGGED":   return self._tagged
        if state == "ROTATE":   return self._rotate_avoider
        
    ######### SEEKER #########
    
    def enemy_detected_seeker(self):
        list_of_colors, area, x_coord = self.camera.detect()
        # print("COLORS:    ", list_of_colors)
        # print("NOOORMM:   ", x_coord)
        if "BLUE" in list_of_colors:
            print("correct: ", x_coord[list_of_colors.index("BLUE")])
            return True, x_coord[list_of_colors.index("BLUE")]
        else:
            return False, 0
            
    def _rotate(self):
        print("ROTATEEE")
        while self.current_state == "ROTATE":
            enemy_present, self.x_coord = self.enemy_detected_seeker()
            if enemy_present:
                self.current_state = "CHASE"
                return
            else:
                self.drive(-100, +100)
                pass

    def _chase(self):
        print("CHASEEEE")
        # get coordinate of enemy
        # run to it
        self.enemy_present, self.x_coord = self.enemy_detected_seeker()
        while self.enemy_present:
            self.enemy_present, self.x_coord = self.enemy_detected_seeker()
            print("X        :", self.x_coord)
            if self.x_coord >= 0.2: 
                self.drive(100,-100)
                pass
            elif self.x_coord <= -0.2:
                self.drive(-100, 100)
                pass
            else:
                self.drive(100, 100)
                pass
        self.current_state = "ROTATE"
        return

    
    def state_switch_SEEKER(self, state):
        if state == "CHASE":      return self._chase
        if state == "ROTATE":     return self._rotate

    ###################################################


# ------------------ Main -------------------------

def main():
    robot = Thymio()
    robot.assignRole("AVOIDER")
    # robot.assignRole("SEEKER")

    # robot.current_state="RUN" if robot.role == "AVOIDER" else "ROTATE"
    # robot.update_colour()
    # for i in range(100000):
    #     print(robot.current_state)
    #     state = robot.state_switch_AVOIDER(robot.current_state) if robot.role == "AVOIDER" \
    #         else robot.state_switch_SEEKER(robot.current_state)
    #     robot.update_colour()
    #     # state()

    while True: 
        l_line, r_line = robot.test_on_line()
        l, r = robot.test_drive(l_line, r_line)
        robot.drive(l,r)

    robot.stop()


# ------------------- Main ------------------------

    


if __name__ == '__main__':
    try:
        main()
        os.system("pkill -n asebamedulla")
    except Exception as e:
        print("Stopping robot with exception:\n\n" + str(e))
        exit_now = True
        sleep(5)
        os.system("pkill -n asebamedulla")
        print("asebamodulla killed")
