import cv2 as cv
import numpy as np

# original (at ITU)   target_hsv=(34, 132, 206)
# at DR building game lab target_hsv=(26, 136, 220)

class ColorDetector:
    def __init__(self, role, min_contour_area=250, ROI=(200,200), ui=False):
        # Detection Settings
        # _roles = {"AVOIDER":{"RED":   {"target_hsv":(172, 182, 255), "hsv_range":(17, 69, 21)}, 
        _roles = {"AVOIDER":{"RED":   {"target_hsv":(167,60,57),        "hsv_range":(179,255,255)}, #niels
                             "ORANGE":{"target_hsv":(15, 150, 255),     "hsv_range":(28, 22, 52)}},
                  "SEEKER": {"BLUE":  {"target_hsv":(105, 109, 255),    "hsv_range":(25, 43, 80)}, 
                             "GREEN": {"target_hsv":(79,79,202),        "hsv_range":(18,47,145)}, 
                             "PURPLE":{"target_hsv":(150,144,255),      "hsv_range":(18,74,26)}}}
        self._colors_of_role = _roles[role]
        self.ROI = ROI
        self.min_contour_area = min_contour_area
        self.ui = ui

        # Video Capture Settings
        self.video_capture_device_index = 0
        self.video = cv.VideoCapture(self.video_capture_device_index)

        # UI
        self.key = None
        if self.ui:
            cv.namedWindow("Original", cv.WINDOW_AUTOSIZE)
            cv.namedWindow("Before", cv.WINDOW_AUTOSIZE)
            cv.namedWindow("After", cv.WINDOW_AUTOSIZE)

            cv.moveWindow("Original", 1300, 30)
            cv.moveWindow("Before", 50, 30)
            cv.moveWindow("After", 700, 30)


    def detect(self, ):
        img = self._get_last_frame()

        if self.ui:
            cv.imshow("Original", img)

        # Image processing
        hsv_img = self._apply_image_processing(img)
        
        # Run detection for each target color
        final_colors_detections = []
        final_x_coord = []
        for color_str in self._colors_of_role:
            hsv_min, hsv_max = self._get_boundaries(
                self._colors_of_role[color_str]["target_hsv"], 
                self._colors_of_role[color_str]["hsv_range"])

            # Color segmentation
            binary_img = cv.inRange(hsv_img, hsv_min, hsv_max)

            if self.ui:
                cv.imshow("Before", binary_img)

            # Morphological operations
            ellipse_kernel = cv.getStructuringElement(cv.MORPH_ELLIPSE, (7, 7))
            morph_img = cv.morphologyEx(binary_img, cv.MORPH_OPEN, ellipse_kernel)
            morph_img = cv.morphologyEx(morph_img, cv.MORPH_CLOSE, ellipse_kernel)

            # Find the contour with the biggest area
            contours, hierarchy = cv.findContours(
                morph_img, cv.RETR_TREE, cv.CHAIN_APPROX_SIMPLE)
            bgr_img = cv.cvtColor(morph_img, cv.COLOR_GRAY2BGR)

            # Highlight the contour
            biggest_contour_area = 0
            normalizedX = 0
            if len(contours) > 0:
                biggest_contour = max(contours, key=cv.contourArea)
                biggest_contour_area = cv.contourArea(biggest_contour)
                # Compute contour's centre coords
                biggest_contour_centre = cv.moments(biggest_contour)
                cX = int(biggest_contour_centre["m10"] / biggest_contour_centre["m00"])
                cY = int(biggest_contour_centre["m01"] / biggest_contour_centre["m00"])
                normalizedX, _ = self._normalize_coords(cX, cY)
                print("NORMALIZZZZ", normalizedX)
                final_x_coord.append(normalizedX)

                line_color = (0, 0, 255)
                cv.drawContours(bgr_img, biggest_contour, -1,
                                line_color, 3)  # -1 = all contours
                
                # Record the detection result
                if biggest_contour_area > 0:
                    final_colors_detections.append(color_str)

                if self.ui:
                    cv.imshow("After", bgr_img)
                    self.key = cv.waitKey(1)

        return final_colors_detections, biggest_contour_area, final_x_coord  #, biggest_contour_area > self.min_contour_area

    def _get_last_frame(self):
        _, last_frame = self.video.read()
        return last_frame

    def _get_last_frame_dimensions(self):
        return self.video.get(cv.CAP_PROP_FRAME_WIDTH), self.video.get(cv.CAP_PROP_FRAME_HEIGHT)

    def _apply_image_processing(self, img):
        img_dimensions = (self._get_last_frame_dimensions())
        #Rotate
        img = cv.rotate(img, cv.ROTATE_90_CLOCKWISE)
        img = cv.rotate(img, cv.ROTATE_90_CLOCKWISE)
        # to ROI
        mid_w, mid_h = int(img_dimensions[0]//2), int(img_dimensions[1]//2)
        mid_ROI_w, mid_ROI_h = int(self.ROI[0]//2), int(self.ROI[1]//2)
        # cropped_img = img[mid_h-mid_ROI_h:mid_h+mid_ROI_h, mid_w-mid_ROI_w:mid_w+mid_ROI_w]
        # to full width
        cropped_img = img[mid_h-mid_ROI_h:mid_h+mid_ROI_h, :]

        #   cv.imshow("ROI", cropped_img)
        # Blur
        blurred_img = cv.GaussianBlur(cropped_img, (7, 7), 0)
        # Convert to HSV color space
        hsv_img = cv.cvtColor(blurred_img, cv.COLOR_BGR2HSV)
        return hsv_img

    def _get_boundaries(self, hsv_target, hsv_range):
        lower_boundary = np.array(hsv_target) - np.array(hsv_range)
        upper_boundary = np.array(hsv_target) + np.array(hsv_range)
        return lower_boundary, upper_boundary

    def _normalize_coords(self, x, y):
        res = [x for x in self._get_last_frame_dimensions()]
        print("X        :", x)
        return [(coord/size)*2-1 for coord,size in zip([x,y], res)]

if __name__ == "__main__":
    """ COLORS LOGIC
    SEEKER:
    base color --> RED
    safe zone  --> ORANGE
    
    AVOIDER
    base color --> BLUE 
    safe zone  --> GREEN
    tagged     --> PURPLE
    """

    avoider_detector = ColorDetector("AVOIDER", ui=False)
    # seeker_detector = ColorDetector("SEEKER", ui=False)

    detector = avoider_detector
    # while detector.key != ord("q"):
    #     area, detected = detector.detect()
    #     print(f"Biggest contour area: {area}    Ball detected: {detected}")

    while detector.key != ord("q"):
        list_of_colors, area, _ = detector.detect()
        for color_result in list_of_colors:
            print(f"{color_result} DETECTED!!!!!!!!!!!")
        print(f"Biggest contour area: {area}")
        print()